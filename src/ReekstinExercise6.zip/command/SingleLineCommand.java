package csci240.prinCad.command;

import csci240.prinCad.ui.Log;
import csci240.prinCad.control.*;
import csci240.prinCad.control.SingleLineTool;
import csci240.prinCad.ui.PrinCanvas;
import csci240.prinCad.control.BoxSelectionTool;
import csci240.prinCad.control.CadTool;
import csci240.prinCad.control.LineSelectionTool;
import javafx.event.ActionEvent;

public class SingleLineCommand  extends CommandHandler {
	
	// Constructor
	public SingleLineCommand(PrinCanvas canvas) {
		super(canvas);
	}

	// Handle action event
	@Override 
	public void action(ActionEvent e) {
		Log.info("Handle Single Line CAD Tools Event");
		
		getCanvas().setActiveTool(new SingleLineTool(_canvas));
		
	}

}