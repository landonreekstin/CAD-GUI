package csci240.prinCad.command;

import csci240.prinCad.control.CadTool;
import csci240.prinCad.ui.Log;
import csci240.prinCad.ui.PrinCanvas;
import javafx.event.ActionEvent;

public class DeleteCommand  extends CommandHandler {
	
	// Constructor
	public DeleteCommand(PrinCanvas canvas) {
		super(canvas);
	}

	// Handle action event
	@Override 
	public void action(ActionEvent e) {
		Log.info("Handle Delete Edit Event");
	}

}