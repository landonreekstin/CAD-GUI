package csci240.prinCad.command;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;

import csci240.prinCad.control.CadTool;
import csci240.prinCad.ui.Log;
import csci240.prinCad.ui.PrinCanvas;
import javafx.event.ActionEvent;
import javafx.stage.FileChooser;
import javafx.stage.Window;

public class OpenFileCommand extends CommandHandler {
	
	// Constructor
	public OpenFileCommand(PrinCanvas canvas) {
		super(canvas);
	}

	// Handle action event
	@Override 
	public void action(ActionEvent e) {
		Log.info("Handle Open File Event");
		
		try {
			Window stage = getCanvas().getScene().getWindow();
			
			FileChooser fileChooser = new FileChooser();
			fileChooser.setTitle("Load Model");
			File file = fileChooser.showOpenDialog(stage);
			
			if (file.exists()) {
				FileReader fr = new FileReader(file);
				BufferedReader reader = new BufferedReader(fr);
				
				getCanvas().loadFromFile(reader);
				getCanvas().setIsModelFile(true);
				getCanvas().passFileName(file);
				
				reader.close();
				fr.close();
			}
		}
		catch (Exception ex) {
			Log.error("", ex);
		}

	}

}
