package csci240.prinCad.command;
import csci240.prinCad.control.CadTool;
import csci240.prinCad.ui.PrinCanvas;
import javafx.event.ActionEvent;

/**
 * Abstract class to handle Edit and File Commands
 */
public abstract class CommandHandler {
	// Owning canvas
	PrinCanvas _canvas;
	public final PrinCanvas getCanvas() { return _canvas; }
	
	// Constructor
	public CommandHandler(PrinCanvas canvas) {
		_canvas = canvas;
	}
		
	// Handle action event
	/**
	 * Controls commands to be executed when File and Edit buttons are pressed
	 */
	public abstract void action(ActionEvent e);

}
