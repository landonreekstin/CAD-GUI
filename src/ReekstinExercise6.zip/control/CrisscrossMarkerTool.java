package csci240.prinCad.control;

import csci240.prinCad.model.CrisscrossMarkerItem;
import csci240.prinCad.model.PlusMarkerItem;
import csci240.prinCad.ui.PrinCanvas;
import javafx.scene.input.MouseEvent;

public class CrisscrossMarkerTool extends MarkerTool {

	public CrisscrossMarkerTool(PrinCanvas canvas) {
		super(canvas);
	}

	@Override
	protected void Draw(MouseEvent e) {
		
		double x = e.getX();
		double y = e.getY();
		
		_canvas.draw();
		
		_canvas.getGC().strokeLine(x - MarkerSize, y - MarkerSize, x + MarkerSize, y + MarkerSize);
		_canvas.getGC().strokeLine(x + MarkerSize, y - MarkerSize, x - MarkerSize, y + MarkerSize);
		_canvas.reset(new CrisscrossMarkerItem(x, y));
	}

}