package csci240.prinCad.control;

import csci240.prinCad.model.CircleItem;
import csci240.prinCad.model.PlusMarkerItem;
import csci240.prinCad.ui.PrinCanvas;
import javafx.scene.input.MouseEvent;

public class PlusMarkerTool extends MarkerTool {

	public PlusMarkerTool(PrinCanvas canvas) {
		super(canvas);
	}

	@Override
	protected void Draw(MouseEvent e) {
		
		double x = e.getX();
		double y = e.getY();
		
		_canvas.draw();
		
		_canvas.getGC().strokeLine(x - MarkerSize, y, x + MarkerSize, y);
		_canvas.getGC().strokeLine(x, y - MarkerSize, x, y + MarkerSize);
		
		_canvas.reset(new PlusMarkerItem(x, y));
	}

}

