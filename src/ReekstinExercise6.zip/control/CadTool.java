package csci240.prinCad.control;

import csci240.prinCad.ui.PrinCanvas;
import javafx.scene.input.MouseEvent;

/**
 * Abstract class for selection tool
 */
public abstract class CadTool {
	PrinCanvas _canvas;
	double _x, _y, _w, _h;
	double _xPivot, _yPivot, _xEnd, _yEnd;
	
	//static boolean toggle = true; // true = square, false = linear, square by default
	
	public CadTool(PrinCanvas canvas) {
		this._canvas = canvas;
	} 
	
	//public static boolean getToggle() {return toggle;}
	//public static void setToggle(boolean toggle) {SelectionCommand.toggle = toggle;}
	
	/**
	 * Controls events when mouse is pressed
	 */
	public abstract void onMousePressed(MouseEvent e);
	/**
	 * Controls events when mouse is dragged
	 */
	public abstract void onMouseDrag(MouseEvent e);
	/**
	 * Controls events when mouse is released
	 */
	public abstract void onMouseReleased(MouseEvent e);

}
