package csci240.prinCad.model;

import csci240.prinCad.ui.Log;
import javafx.scene.canvas.GraphicsContext;

public class SingleLineItem extends CadItem {
	
	public final double _xS;
	public final double _yS;
	public final double _xE;
	public final double _yE;
	
	public SingleLineItem(double xS, double yS, double xE, double yE) {
		_xS = xS;
		_yS = yS;
		_xE = xE;
		_yE = yE;
	}
	
	// load rectangle item from string data
	public static SingleLineItem load(String data) {
		
		SingleLineItem item = null;
		try {
			String[] tokens = data.split(" ");
			double xS = Double.parseDouble(tokens[0]);
			double yS = Double.parseDouble(tokens[1]);
			double xE  = Double.parseDouble(tokens[2]);
			double yE  = Double.parseDouble(tokens[3]);
			item = new SingleLineItem(xS, yS, xE, yE);
		}
		catch (Exception ex) {
			Log.error("Invalid SingleLineTool data string: " + data, ex);
		}
		return item;
	}


	@Override
	public void draw(GraphicsContext gc) {
		gc.strokeLine(_xS, _yS, _xE, _yE);
	}

	@Override
	public String save() {
		return String.format("%1$f %2$f %3$f %4$f", _xS, _yS, _xE, _yE);
	}
}


