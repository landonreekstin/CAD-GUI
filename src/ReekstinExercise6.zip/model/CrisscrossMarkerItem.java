package csci240.prinCad.model;

import csci240.prinCad.ui.Log;
import javafx.scene.canvas.GraphicsContext;

public class CrisscrossMarkerItem extends CadItem {
	
	public final double _x;
	public final double _y;
	public final double markerSize = 4;
	
	public CrisscrossMarkerItem(double x, double y) {
		_x = x;
		_y = y;
	}
	
	// load rectangle item from string data
	public static CrisscrossMarkerItem load(String data) {
		
		CrisscrossMarkerItem item = null;
		try {
			String[] tokens = data.split(" ");
			double x = Double.parseDouble(tokens[0]);
			double y = Double.parseDouble(tokens[1]);
			item = new CrisscrossMarkerItem(x, y);
		}
		catch (Exception ex) {
			Log.error("Invalid CrisscrossMarkerTool data string: " + data, ex);
		}
		return item;
	}


	@Override
	public void draw(GraphicsContext gc) {
		gc.strokeLine(_x - markerSize, _y - markerSize, _x + markerSize, _y + markerSize);
		gc.strokeLine(_x + markerSize, _y - markerSize, _x - markerSize, _y + markerSize);
	}

	@Override
	public String save() {
		return String.format("%1$f %2$f", _x, _y);
	}
}
