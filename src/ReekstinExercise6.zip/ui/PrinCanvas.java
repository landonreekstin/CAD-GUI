package csci240.prinCad.ui;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

import java.io.BufferedReader;
import java.io.File;
import java.io.PrintWriter;
import java.util.stream.Collectors;

import csci240.prinCad.control.BoxSelectionTool;
import csci240.prinCad.control.CadTool;
import csci240.prinCad.control.LineSelectionTool;
import csci240.prinCad.model.CadItem;
import csci240.prinCad.model.ModelManager;
import javafx.scene.Cursor;

//Drawing canvas for the Prin CAD tools application
/**
 * Creates canvas and graphics for all drawing on the canvas
 */
public class PrinCanvas extends Canvas {
	
	// file state
	boolean isModelFile = false;
	String currentFile;
	
	// Current selection tool
	CadTool _selectionTool;
	
	// model manager
	private ModelManager _model;
	
	// Reference to graphics context
	GraphicsContext _gc;
	public GraphicsContext getGC() { return _gc; }
	
	// Active tool - may not be a selection tool
	private CadTool _activeTool;
	public void setActiveTool(CadTool activeTool) { _activeTool = activeTool; }
	
	// Mouse movement properties
	boolean _activeMouse;
	double _xPivot, _yPivot, _xEnd, _yEnd;
	
	// Data constructor
	public PrinCanvas(double width, double height) {
		// invoke (call) parent class constructor
		super(width, height);
		
		// Initialize model manager
		_model = new ModelManager();
		
		// Get graphics context and fill with background color
		_gc = getGraphicsContext2D();
		// Convert int[] from txt file to RGB argument
		Color canvasHexColor = Color.valueOf(MainForm.settings.getCanvasBackgroundColor());
		_gc.setFill(canvasHexColor);
		_gc.fillRect(0, 0, MainForm.settings.getCanvasWidth(), MainForm.settings.getCanvasHeight());
		
		// Subscribe to mouse events
		setOnMousePressed(e -> _activeTool.onMousePressed(e));
		setOnMouseDragged(e -> _activeTool.onMouseDrag(e));
		setOnMouseReleased(e -> _activeTool.onMouseReleased(e));
		
		// Set default selection
		_selectionTool = new BoxSelectionTool(this);
		_activeTool = _selectionTool;
		
	}
	
	public boolean getIsModelFile() {return isModelFile;}
	public String getCurrentFile() {return currentFile;}
	public void setIsModelFile(boolean isModelFile) {this.isModelFile = isModelFile;}
	public void setCurrentFile(String currentFile) {this.currentFile = currentFile;}
	
	/**
	 * Allows selection tool toggle to be translated to current canvas
	 */
	public void toggleSelection() {
		
		if (_selectionTool instanceof BoxSelectionTool)
			_selectionTool = new LineSelectionTool(this);
		else
			_selectionTool = new BoxSelectionTool(this);
		
		_activeTool = _selectionTool;
	}
	
	// Set back to selection mode
	public void reset() {
		_activeTool = _selectionTool;
	}
	
	// Save created CAD item and set back to selection mode
	public void reset(CadItem cadItem) {
		_model.add(cadItem);
		_activeTool = _selectionTool;
	}
	
	// Draw all graphic objects
	public void draw() {
		_gc.fillRect(0, 0, getWidth(), getHeight());
		_gc.setStroke(Color.ORANGERED);
		_gc.setLineWidth(0);
		_model.draw(_gc);
	}
	
	// Clear screen
	public void clear() {
		_gc.clearRect(0, 0, MainForm.settings.getCanvasWidth(), MainForm.settings.getCanvasHeight());
		// Redraw Canvas
		Color canvasHexColor = Color.valueOf(MainForm.settings.getCanvasBackgroundColor());
		_gc.setFill(canvasHexColor);
		_gc.fillRect(0, 0, MainForm.settings.getCanvasWidth(), MainForm.settings.getCanvasHeight());
		_model.clear();
	}

	// Persist data
	public void saveToFile(PrintWriter out) {
		_model.save(out);
	}
	
	public void loadFromFile(BufferedReader reader) {
		_model.clear();
		_model.load(reader);
		draw();
	}
	
	public void passFileName(File file) {
		this.currentFile = file.getPath();
	}
	
}


