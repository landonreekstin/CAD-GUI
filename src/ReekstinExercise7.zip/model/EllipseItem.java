package csci240.prinCad.model;

import csci240.prinCad.util.Log;
import javafx.scene.canvas.GraphicsContext;

public class EllipseItem extends CadItem {
	
	public final double _xCenter;
	public final double _yCenter;
	public final double _w;
	public final double _h;
	
	public EllipseItem(double xCenter, double yCenter, double width, double height) {
		_xCenter = xCenter;
		_yCenter = yCenter;
		_w = width;
		_h = height;
	}
	
	// load circle item from string data
	public static EllipseItem load(String data) {
		
		EllipseItem item = null;
		try {
			String[] tokens = data.split(" ");
			double xc = Double.parseDouble(tokens[0]);
			double yc = Double.parseDouble(tokens[1]);
			double w  = Double.parseDouble(tokens[2]);
			double h  = Double.parseDouble(tokens[3]);
			item = new EllipseItem(xc, yc, w, h);
		}
		catch (Exception ex) {
			Log.error("Invalid EllipseTool data string: " + data, ex);
		}
		return item;
	}


	@Override
	public void draw(GraphicsContext gc) {
		gc.strokeOval(_xCenter - _w, _yCenter - _h, 2 * _w, 2 * _h);
	}

	@Override
	public String save() {
		return String.format("%1$f %2$f %3$f %4$f", _xCenter, _yCenter, _w, _h);
	}
}


