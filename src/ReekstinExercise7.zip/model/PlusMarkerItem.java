package csci240.prinCad.model;

import csci240.prinCad.util.Log;
import javafx.scene.canvas.GraphicsContext;

public class PlusMarkerItem extends CadItem {
	
	public final double _x;
	public final double _y;
	public final double markerSize = 4;
	
	public PlusMarkerItem(double x, double y) {
		_x = x;
		_y = y;
	}
	
	// load rectangle item from string data
	public static PlusMarkerItem load(String data) {
		
		PlusMarkerItem item = null;
		try {
			String[] tokens = data.split(" ");
			double x = Double.parseDouble(tokens[0]);
			double y = Double.parseDouble(tokens[1]);
			item = new PlusMarkerItem(x, y);
		}
		catch (Exception ex) {
			Log.error("Invalid PlusMarkerTool data string: " + data, ex);
		}
		return item;
	}


	@Override
	public void draw(GraphicsContext gc) {
		gc.strokeLine(_x - markerSize, _y, _x + markerSize, _y);
		gc.strokeLine(_x, _y - markerSize, _x, _y + markerSize);
	}

	@Override
	public String save() {
		return String.format("%1$f %2$f", _x, _y);
	}
}
