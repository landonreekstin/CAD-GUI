package csci240.prinCad.ui;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import csci240.prinCad.control.BoxSelectionTool;
import csci240.prinCad.control.CadTool;
import csci240.prinCad.control.LineSelectionTool;
import javafx.scene.Cursor;

//Drawing canvas for the Prin CAD tools application
/**
 * Creates canvas and graphics for all drawing on the canvas
 */
public class PrinCanvas extends Canvas {
	
	// Current selection tool
	CadTool _selectionTool;
	
	// Reference to graphics context
	GraphicsContext _gc;
	public GraphicsContext getGC() { return _gc; }
	
	// Active tool - may not be a selection tool
	private CadTool _activeTool;
	public void setActiveTool(CadTool activeTool) { _activeTool = activeTool; }
	
	// Mouse movement properties
	boolean _activeMouse;
	double _xPivot, _yPivot, _xEnd, _yEnd;
	
	// Data constructor
	public PrinCanvas(double width, double height) {
		// invoke (call) parent class constructor
		super(width, height);
		
		// Get graphics context and fill with background color
		_gc = getGraphicsContext2D();
		// Convert int[] from txt file to RGB argument
		Color canvasHexColor = Color.valueOf(MainForm.settings.getCanvasBackgroundColor());
		_gc.setFill(canvasHexColor);
		_gc.fillRect(0, 0, MainForm.settings.getCanvasWidth(), MainForm.settings.getCanvasHeight());
		
		// Subscribe to mouse events
		setOnMousePressed(e -> _activeTool.onMousePressed(e));
		setOnMouseDragged(e -> _activeTool.onMouseDrag(e));
		setOnMouseReleased(e -> _activeTool.onMouseReleased(e));
		
		// Set default selection
		_selectionTool = new BoxSelectionTool(this);
		_activeTool = _selectionTool;
		
	}
	
	/**
	 * Allows selection tool toggle to be translated to current canvas
	 */
	public void toggleSelection() {
		
		if (_selectionTool instanceof BoxSelectionTool)
			_selectionTool = new LineSelectionTool(this);
		else
			_selectionTool = new BoxSelectionTool(this);
		
		_activeTool = _selectionTool;
	}
	
	// Set back to selection mode
	public void reset() {
		_activeTool = _selectionTool;
	}
	
}


