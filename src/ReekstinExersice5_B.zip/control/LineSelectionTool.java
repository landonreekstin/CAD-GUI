package csci240.prinCad.control;

import csci240.prinCad.ui.PrinCanvas;
import javafx.scene.Cursor;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;

/**
 * Controls linear selection
 */
public class LineSelectionTool extends CadTool{
	
	// Reference to graphics context
	GraphicsContext _gc;
	
	// Mouse movement properties
	boolean _activeMouse;
	
	// Constructor
	public LineSelectionTool (PrinCanvas canvas) {
		super(canvas);
	}
	
	@Override
	// Handle mouse pressed (button down)
	public void onMousePressed(MouseEvent e) {
		if (e.getButton() == MouseButton.PRIMARY) {
			_x = e.getX();
			_y = e.getY();
			_xPivot = _x;
			_yPivot = _y;
			_xEnd = _x;
			_yEnd = _y;
			_activeMouse = true;
			_gc = _canvas.getGraphicsContext2D();
			_gc.setStroke(Color.ORANGERED);
			_gc.setLineWidth(0);
			_canvas.setCursor(Cursor.CROSSHAIR);
		}
	}
	
	@Override
	// Handle mouse drag (only called when mouse button IS depressed)
		public void onMouseDrag(MouseEvent e) {
			if (_activeMouse) {
				_x = Math.min(_xPivot, _xEnd) - 1;
				_y = Math.min(_yPivot, _yEnd) - 1;
				_w = Math.abs(_xEnd - _xPivot) + 2;
				_h = Math.abs(_yEnd - _yPivot) + 2;
				_gc.fillRect(_x,  _y,  _w,  _h);
				_xEnd = e.getX();
				_yEnd = e.getY();
				_gc.strokeLine(_xPivot, _yPivot, _xEnd, _yEnd);
			}
		}
		
		@Override
		// Handle mouse release (button up)
		public void onMouseReleased(MouseEvent e) {
			if (_activeMouse) {
				_activeMouse = false;
				_canvas.setCursor(Cursor.DEFAULT);
				_gc = null;
			}
		}
		
}
