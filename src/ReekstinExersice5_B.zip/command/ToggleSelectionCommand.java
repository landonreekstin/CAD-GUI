package csci240.prinCad.command;

import csci240.prinCad.ui.Log;
import csci240.prinCad.ui.PrinCanvas;
import csci240.prinCad.control.BoxSelectionTool;
import csci240.prinCad.control.CadTool;
import csci240.prinCad.control.LineSelectionTool;
import javafx.event.ActionEvent;

public class ToggleSelectionCommand  extends CommandHandler {
	
	// Constructor
	public ToggleSelectionCommand(PrinCanvas canvas) {
		super(canvas);
	}

	// Handle action event
	@Override 
	public void action(ActionEvent e) {
		Log.info("Handle Toggle Selection Edit Event");
		
		this._canvas.toggleSelection();
		
	}

}