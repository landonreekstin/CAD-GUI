package csci240.prinCad.command;

import csci240.prinCad.control.CadTool;
import csci240.prinCad.ui.Log;
import csci240.prinCad.ui.PrinCanvas;
import javafx.event.ActionEvent;

public class UndoCommand  extends CommandHandler {
	
	// Constructor
	public UndoCommand(PrinCanvas canvas) {
		super(canvas);
	}

	// Handle action event
	@Override 
	public void action(ActionEvent e) {
		Log.info("Handle Undo Edit Event");
	}

}
