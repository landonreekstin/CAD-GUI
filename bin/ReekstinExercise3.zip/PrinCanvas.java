package csci240.prinCad.ui;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;
import javafx.scene.Cursor;

//Drawing canvas for the Prin CAD tools application
public class PrinCanvas extends Canvas {
	SelectionCommand _sc;
	
	// Reference to graphics context
	GraphicsContext _gc;
	
	// Mouse movement properties
	boolean _activeMouse;
	double _xPivot, _yPivot, _xEnd, _yEnd;
	
	// Data constructor
	public PrinCanvas(double width, double height) {
		// invoke (call) parent class constructor
		super(width, height);
		
		// Modify to change selection tool
		 //_sc = new LinSelect(this);
		 _sc = new RectSelect(this);
		
		// Subscribe to mouse events
		setOnMousePressed(e -> _sc.onMousePressed(e));
		setOnMouseDragged(e -> _sc.onMouseDrag(e));
		setOnMouseReleased(e -> _sc.onMouseReleased(e));
		
		// Get graphics context and fill with background color
		_gc = getGraphicsContext2D();
		// Convert int[] from txt file to RGB argument
		Color canvasHexColor = Color.valueOf(MainForm.settings.getCanvasBackgroundColor());
		_gc.setFill(canvasHexColor);
		_gc.fillRect(0, 0, MainForm.settings.getCanvasWidth(), MainForm.settings.getCanvasHeight());
		
	}
	
	
	
}


