package csci240.prinCad.command;

import csci240.prinCad.ui.Log;
import csci240.prinCad.ui.PrinCanvas;
import csci240.prinCad.ui.SelectionCommand;
import javafx.event.ActionEvent;

public class SaveFileCommand extends CommandHandler {
	
	// Constructor
	public SaveFileCommand(PrinCanvas canvas) {
		super(canvas);
	}

	// Handle action event
	@Override 
	public void action(ActionEvent e) {
		Log.info("Handle Save File Event");
	}

}
