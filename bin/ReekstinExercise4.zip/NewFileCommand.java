package csci240.prinCad.command;

import csci240.prinCad.ui.Log;
import csci240.prinCad.ui.PrinCanvas;
import csci240.prinCad.ui.SelectionCommand;
import javafx.event.ActionEvent;

public class NewFileCommand extends CommandHandler {
	
	// Constructor
	public NewFileCommand(PrinCanvas canvas) {
		super(canvas);
	}

	// Handle action event
	@Override 
	public void action(ActionEvent e) {
		Log.info("Handle New File Event");
	}

}
