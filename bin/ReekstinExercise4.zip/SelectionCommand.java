package csci240.prinCad.ui;

import javafx.scene.input.MouseEvent;

public abstract class SelectionCommand {
	PrinCanvas canvas;
	double _x, _y, _w, _h;
	double _xPivot, _yPivot, _xEnd, _yEnd;
	double _rectXStart, _rectYStart;
	//static boolean toggle = true; // true = square, false = linear, square by default
	
	public SelectionCommand(PrinCanvas canvas) {
		this.canvas = canvas;
	} 
	
	//public static boolean getToggle() {return toggle;}
	//public static void setToggle(boolean toggle) {SelectionCommand.toggle = toggle;}
	
	public abstract void onMousePressed(MouseEvent e);
	public abstract void onMouseDrag(MouseEvent e);
	public abstract void onMouseReleased(MouseEvent e);

}
