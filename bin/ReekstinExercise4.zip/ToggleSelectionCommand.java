package csci240.prinCad.command;

import csci240.prinCad.ui.LinSelect;
import csci240.prinCad.ui.Log;
import csci240.prinCad.ui.PrinCanvas;
import csci240.prinCad.ui.RectSelect;
import csci240.prinCad.ui.SelectionCommand;
import javafx.event.ActionEvent;

public class ToggleSelectionCommand  extends CommandHandler {
	
	// Constructor
	public ToggleSelectionCommand(PrinCanvas canvas) {
		super(canvas);
	}

	// Handle action event
	@Override 
	public void action(ActionEvent e) {
		Log.info("Handle Toggle Selection Edit Event");
		
		this._canvas.toggleSelection();
		
	}

}