package csci240.prinCad.command;

import csci240.prinCad.ui.Log;
import csci240.prinCad.ui.PrinCanvas;
import csci240.prinCad.ui.SelectionCommand;
import javafx.event.ActionEvent;

public class PropertiesCommand  extends CommandHandler {
	
	// Constructor
	public PropertiesCommand(PrinCanvas canvas) {
		super(canvas);
	}

	// Handle action event
	@Override 
	public void action(ActionEvent e) {
		Log.info("Handle Properties Edit Event");
	}

}