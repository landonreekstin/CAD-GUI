package csci240.prinCad.ui;

import javafx.scene.input.MouseEvent;

public abstract class SelectionCommand {
	PrinCanvas canvas;
	double _x, _y, _w, _h;
	double _xPivot, _yPivot, _xEnd, _yEnd;
	double _rectXStart, _rectYStart;
	
	public SelectionCommand(PrinCanvas canvas) {
		this.canvas = canvas;
	}
	
	public abstract void onMousePressed(MouseEvent e);
	public abstract void onMouseDrag(MouseEvent e);
	public abstract void onMouseReleased(MouseEvent e);

}
