/* Landon Reekstin
 * CSCI 240
 * PrinCAD Spring 2021
 * 
 *  References: W3Schools.com*/


package csci240.prinCad.ui;

import java.io.FileNotFoundException;
import javafx.application.Application;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainForm extends Application {
	
	// Initialize deafault settings
	static UserSettings settings = new UserSettings();
	
	public static void main(String[] args) throws FileNotFoundException {
        
        // Load and set settings from file or default class settings
        settings.setSettings();
	
		// Launch the javaFX application
				launch(args);
				
		// Write to file with current variables
				
		settings.saveSettings();
		
		
	}
	
	// Override the start
	@Override public void start(Stage primaryStage) {
		
		// Create drawing canvas 
		PrinCanvas canvas = new PrinCanvas(settings.getCanvasWidth(), settings.getCanvasHeight());
		
		// Convert int[] from txt file to RGB argument
		Color sceneHexColor = Color.valueOf(settings.getSceneBackgroundColor());
		
		// Create the typical monolithic border layout
		// Attach canvas to center of layout
		BorderPane pane = new BorderPane(canvas);
		
		// Create a scene, attach a layout pane to scene,
		// set the initial size and background color
		Scene scene = new Scene(pane, settings.getSceneWidth(), settings.getSceneHeight(), sceneHexColor);
		
		// Attach scene to stage
		primaryStage.setScene(scene);
		primaryStage.setTitle("CSCI 240 PrinCad Project");
        primaryStage.show();
	}
}
